function prvi(){
    document.getElementById("botun").style.backgroundColor="white";
    document.getElementById("botun").style.color="black";
    document.getElementById("botun").style.transition=".5s";
    document.getElementById("sedma").style.filter="brightness(30%)";
}

function prvi2(){
    document.getElementById("botun").style.backgroundColor="rgba(255, 255, 255, 0)";
    document.getElementById("botun").style.color="white";
    document.getElementById("botun").style.transition=".5s";
    document.getElementById("sedma").style.filter="brightness(30%)";
}

function drugi(){
    document.getElementById("botun2").style.color="grey";
    document.getElementById("botun2").style.transition=".5s";
    document.getElementById("osma").style.filter="brightness(30%)";
}

function drugi2(){
    document.getElementById("botun2").style.color="white";
    document.getElementById("botun2").style.transition=".5s";
    document.getElementById("osma").style.filter="brightness(30%)";
}

function treci(){
    document.getElementById("botun3").style.textDecoration="underline";
    document.getElementById("botun3").style.transition=".5s";
}

function treci2(){
    document.getElementById("botun3").style.textDecoration="none";
    document.getElementById("botun3").style.transition=".5s";
}

function cetvrti(){
    document.getElementById("botun4").style.textDecoration="underline";
    document.getElementById("botun4").style.transition=".5s";
}

function cetvrti2(){
    document.getElementById("botun4").style.textDecoration="none";
    document.getElementById("botun4").style.transition=".5s";
}

function sedma(){
    document.getElementById("sedma").style.filter="brightness(60%)"
    document.getElementById("sedma").style.transition=".5s";
}

function osma(){
    document.getElementById("osma").style.filter="brightness(60%)"
    document.getElementById("osma").style.transition=".5s";
}

function sedma2(){
    document.getElementById("sedma").style.filter="brightness(30%)"
    document.getElementById("sedma").style.transition=".5s";
}

function osma2(){
    document.getElementById("osma").style.filter="brightness(30%)"
    document.getElementById("osma").style.transition=".5s";
}