function botun(){
    document.getElementById("botun").style.backgroundColor="rgba(255, 255, 255, 0)";
    document.getElementById("botun").style.color="white";
    document.getElementById("botun").style.transition=".5s";
    document.getElementById("prva").style.filter="brightness(30%)";
}

function botun2(){
    document.getElementById("botun").style.backgroundColor="white";
    document.getElementById("botun").style.color="black";
    document.getElementById("botun").style.transition=".5s";
    document.getElementById("osma").style.filter="brightness(30%)";
}

function prva(){
    document.getElementById("prva").style.transition=".5s";
    document.getElementById("prva").style.filter="brightness(30%)";
}

function prva2(){
    document.getElementById("prva").style.transition=".5s";
    document.getElementById("prva").style.filter="brightness(60%)";
}


function predi(){
    document.getElementById("botun2").style.backgroundColor="rgba(255, 255, 255, 0)";
    document.getElementById("botun2").style.color="white";
    document.getElementById("botun2").style.transition=".5s";
    document.getElementById("osma").style.filter="brightness(30%)";
}

function makni(){
    document.getElementById("botun2").style.backgroundColor="white";
    document.getElementById("botun2").style.color="black";
    document.getElementById("botun2").style.transition=".5s";
    document.getElementById("osma").style.filter="brightness(30%)";
}

function osma(){
    document.getElementById("osma").style.transition=".5s";
    document.getElementById("osma").style.filter="brightness(30%)";
}

function osma2(){
    document.getElementById("osma").style.transition=".5s";
    document.getElementById("osma").style.filter="brightness(60%)";
}


