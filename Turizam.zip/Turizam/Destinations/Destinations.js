function prva(){
    document.getElementById("prva").style.transition=".5s"
    document.getElementById("prva").style.filter="brightness(30%)";
    document.getElementById("botuni_prvi").style.visibility="visible";
}

function prva2(){
    document.getElementById("prva").style.filter="brightness(60%)";
    document.getElementById("botuni_prvi").style.visibility="hidden";
}

function predi(){
    document.getElementById("prva").style.filter="brightness(30%)";
    document.getElementById("botuni_prvi").style.visibility="visible";
}

function makni(){
    document.getElementById("prva").style.filter="brightness(30%)";
    document.getElementById("botuni_prvi").style.visibility="visible";
}

function a(){
    document.getElementById("prvi").style.transition=".5s"
    document.getElementById("prvi").style.backgroundColor="white";
    document.getElementById("prvi").style.color="red";
}

function a2(){
    document.getElementById("prvi").style.transition=".5s"
    document.getElementById("prvi").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("prvi").style.color="white";
}

function b(){
    document.getElementById("drugi").style.transition=".5s"
    document.getElementById("drugi").style.backgroundColor="white";
    document.getElementById("drugi").style.color="red";
}

function b2(){
    document.getElementById("drugi").style.transition=".5s"
    document.getElementById("drugi").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("drugi").style.color="white";
}

function c(){
    document.getElementById("treci").style.transition=".5s"
    document.getElementById("treci").style.backgroundColor="white";
    document.getElementById("treci").style.color="red";
}

function c2(){
    document.getElementById("treci").style.transition=".5s"
    document.getElementById("treci").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("treci").style.color="white";
}

function druga(){
    document.getElementById("druga").style.transition=".5s"
    document.getElementById("druga").style.filter="brightness(30%)";
    document.getElementById("botuni_drugi").style.visibility="visible";
}

function druga2(){
    document.getElementById("druga").style.filter="brightness(60%)";
    document.getElementById("botuni_drugi").style.visibility="hidden";
}

function predi2(){
    document.getElementById("druga").style.filter="brightness(30%)";
    document.getElementById("botuni_drugi").style.visibility="visible";
}

function makni2(){
    document.getElementById("druga").style.filter="brightness(30%)";
    document.getElementById("botuni_drugi").style.visibility="visible";
}

function d(){
    document.getElementById("cetvrti").style.transition=".5s"
    document.getElementById("cetvrti").style.backgroundColor="white";
    document.getElementById("cetvrti").style.color="red";
}

function d2(){
    document.getElementById("cetvrti").style.transition=".5s"
    document.getElementById("cetvrti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("cetvrti").style.color="white";
}

function e(){
    document.getElementById("peti").style.transition=".5s"
    document.getElementById("peti").style.backgroundColor="white";
    document.getElementById("peti").style.color="red";
}

function e2(){
    document.getElementById("peti").style.transition=".5s"
    document.getElementById("peti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("peti").style.color="white";
}

function f(){
    document.getElementById("sesti").style.transition=".5s"
    document.getElementById("sesti").style.backgroundColor="white";
    document.getElementById("sesti").style.color="red";
}

function f2(){
    document.getElementById("sesti").style.transition=".5s"
    document.getElementById("sesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("sesti").style.color="white";
}

function treca(){
    document.getElementById("treca").style.transition=".5s"
    document.getElementById("treca").style.filter="brightness(30%)";
    document.getElementById("botuni_treci").style.visibility="visible";
}

function treca2(){
    document.getElementById("treca").style.filter="brightness(60%)";
    document.getElementById("botuni_treci").style.visibility="hidden";
}

function predi3(){
    document.getElementById("treca").style.filter="brightness(30%)";
    document.getElementById("botuni_treci").style.visibility="visible";
}

function makni3(){
    document.getElementById("treca").style.filter="brightness(30%)";
    document.getElementById("botuni_treci").style.visibility="visible";
}

function g(){
    document.getElementById("sedmi").style.transition=".5s"
    document.getElementById("sedmi").style.backgroundColor="white";
    document.getElementById("sedmi").style.color="red";
}

function g2(){
    document.getElementById("sedmi").style.transition=".5s"
    document.getElementById("sedmi").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("sedmi").style.color="white";
}

function h(){
    document.getElementById("osmi").style.transition=".5s"
    document.getElementById("osmi").style.backgroundColor="white";
    document.getElementById("osmi").style.color="red";
}

function h2(){
    document.getElementById("osmi").style.transition=".5s"
    document.getElementById("osmi").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("osmi").style.color="white";
}

function i(){
    document.getElementById("deveti").style.transition=".5s"
    document.getElementById("deveti").style.backgroundColor="white";
    document.getElementById("deveti").style.color="red";
}

function i2(){
    document.getElementById("deveti").style.transition=".5s"
    document.getElementById("deveti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("deveti").style.color="white";
}

function cetvrta(){
    document.getElementById("cetvrta").style.transition=".5s"
    document.getElementById("cetvrta").style.filter="brightness(30%)";
    document.getElementById("botuni_cetvrti").style.visibility="visible";
}

function cetvrta2(){
    document.getElementById("cetvrta").style.filter="brightness(60%)";
    document.getElementById("botuni_cetvrti").style.visibility="hidden";
}

function predi4(){
    document.getElementById("cetvrta").style.filter="brightness(30%)";
    document.getElementById("botuni_cetvrti").style.visibility="visible";
}

function makni4(){
    document.getElementById("cetvrta").style.filter="brightness(30%)";
    document.getElementById("botuni_cetvrti").style.visibility="visible";
}

function j(){
    document.getElementById("deseti").style.transition=".5s"
    document.getElementById("deseti").style.backgroundColor="white";
    document.getElementById("deseti").style.color="red";
}

function j2(){
    document.getElementById("deseti").style.transition=".5s"
    document.getElementById("deseti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("deseti").style.color="white";
}

function k(){
    document.getElementById("jedanaesti").style.transition=".5s"
    document.getElementById("jedanaesti").style.backgroundColor="white";
    document.getElementById("jedanaesti").style.color="red";
}

function k2(){
    document.getElementById("jedanaesti").style.transition=".5s"
    document.getElementById("jedanaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("jedanaesti").style.color="white";
}

function l(){
    document.getElementById("dvanaesti").style.transition=".5s"
    document.getElementById("dvanaesti").style.backgroundColor="white";
    document.getElementById("dvanaesti").style.color="red";
}

function l2(){
    document.getElementById("dvanaesti").style.transition=".5s"
    document.getElementById("dvanaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvanaesti").style.color="white";
}

function peta(){
    document.getElementById("peta").style.transition=".5s"
    document.getElementById("peta").style.filter="brightness(30%)";
    document.getElementById("botuni_peti").style.visibility="visible";
}

function peta2(){
    document.getElementById("peta").style.filter="brightness(60%)";
    document.getElementById("botuni_peti").style.visibility="hidden";
}

function predi5(){
    document.getElementById("peta").style.filter="brightness(30%)";
    document.getElementById("botuni_peti").style.visibility="visible";
}

function makni5(){
    document.getElementById("peta").style.filter="brightness(30%)";
    document.getElementById("botuni_peti").style.visibility="visible";
}

function m(){
    document.getElementById("trinaesti").style.transition=".5s"
    document.getElementById("trinaesti").style.backgroundColor="white";
    document.getElementById("trinaesti").style.color="red";
}

function m2(){
    document.getElementById("trinaesti").style.transition=".5s"
    document.getElementById("trinaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("trinaesti").style.color="white";
}

function n(){
    document.getElementById("cetrnaesti").style.transition=".5s"
    document.getElementById("cetrnaesti").style.backgroundColor="white";
    document.getElementById("cetrnaesti").style.color="red"; 
}

function n2(){
    document.getElementById("cetrnaesti").style.transition=".5s"
    document.getElementById("cetrnaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("cetrnaesti").style.color="white"; 

}
 function o(){
    document.getElementById("petnaesti").style.transition=".5s"
    document.getElementById("petnaesti").style.backgroundColor="white";
    document.getElementById("petnaesti").style.color="red";
 }

 function o2(){
    document.getElementById("petnaesti").style.transition=".5s"
    document.getElementById("petnaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("petnaesti").style.color="white";
}

function sesta(){
    document.getElementById("sesta").style.transition=".5s"
    document.getElementById("sesta").style.filter="brightness(30%)";
    document.getElementById("botuni_sesti").style.visibility="visible";
}

function sesta2(){
    document.getElementById("sesta").style.filter="brightness(60%)";
    document.getElementById("botuni_sesti").style.visibility="hidden";
}

function predi6(){
    document.getElementById("sesta").style.filter="brightness(30%)";
    document.getElementById("botuni_sesti").style.visibility="visible";
}

function makni6(){
    document.getElementById("sesta").style.filter="brightness(30%)";
    document.getElementById("botuni_sesti").style.visibility="visible";
}

function p(){
    document.getElementById("sestnaesti").style.transition=".5s"
    document.getElementById("sestnaesti").style.backgroundColor="white";
    document.getElementById("sestnaesti").style.color="red";
}

function p2(){
    document.getElementById("sestnaesti").style.transition=".5s"
    document.getElementById("sestnaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("sestnaesti").style.color="white";
}

function r(){
    document.getElementById("sedamnaesti").style.transition=".5s"
    document.getElementById("sedamnaesti").style.backgroundColor="white";
    document.getElementById("sedamnaesti").style.color="red"; 
}

function r2(){
    document.getElementById("sedamnaesti").style.transition=".5s"
    document.getElementById("sedamnaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("sedamnaesti").style.color="white"; 

}
 function s(){
    document.getElementById("osamnaesti").style.transition=".5s"
    document.getElementById("osamnaesti").style.backgroundColor="white";
    document.getElementById("osamnaesti").style.color="red";
 }

 function s2(){
    document.getElementById("osamnaesti").style.transition=".5s"
    document.getElementById("osamnaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("osamnaesti").style.color="white";
}

function sedma(){
    document.getElementById("sedma").style.transition=".5s"
    document.getElementById("sedma").style.filter="brightness(30%)";
    document.getElementById("botuni_sedmi").style.visibility="visible";
}

function sedma2(){
    document.getElementById("sedma").style.filter="brightness(60%)";
    document.getElementById("botuni_sedmi").style.visibility="hidden";
}

function predi7(){
    document.getElementById("sedma").style.filter="brightness(30%)";
    document.getElementById("botuni_sedmi").style.visibility="visible";
}

function makni7(){
    document.getElementById("sedma").style.filter="brightness(30%)";
    document.getElementById("botuni_sedmi").style.visibility="visible";
}

function t(){
    document.getElementById("devetnaesti").style.transition=".5s"
    document.getElementById("devetnaesti").style.backgroundColor="white";
    document.getElementById("devetnaesti").style.color="red";
}

function t2(){
    document.getElementById("devetnaesti").style.transition=".5s"
    document.getElementById("devetnaesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("devetnaesti").style.color="white";
}

function u(){
    document.getElementById("dvadeseti").style.transition=".5s"
    document.getElementById("dvadeseti").style.backgroundColor="white";
    document.getElementById("dvadeseti").style.color="red"; 
}

function u2(){
    document.getElementById("dvadeseti").style.transition=".5s"
    document.getElementById("dvadeseti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadeseti").style.color="white"; 

}
 function v(){
    document.getElementById("dvadesetprvi").style.transition=".5s"
    document.getElementById("dvadesetprvi").style.backgroundColor="white";
    document.getElementById("dvadesetprvi").style.color="red";
 }

 function v2(){
    document.getElementById("dvadesetprvi").style.transition=".5s"
    document.getElementById("dvadesetprvi").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadesetprvi").style.color="white";
}

function osma(){
    document.getElementById("osma").style.transition=".5s"
    document.getElementById("osma").style.filter="brightness(30%)";
    document.getElementById("botuni_osmi").style.visibility="visible";
}

function osma2(){
    document.getElementById("osma").style.filter="brightness(60%)";
    document.getElementById("botuni_osmi").style.visibility="hidden";
}

function predi8(){
    document.getElementById("osma").style.filter="brightness(30%)";
    document.getElementById("botuni_osmi").style.visibility="visible";
}

function makni8(){
    document.getElementById("osma").style.filter="brightness(30%)";
    document.getElementById("botuni_osmi").style.visibility="visible";
}

function dvadesetdrugi(){
    document.getElementById("dvadesetdrugi").style.transition=".5s"
    document.getElementById("dvadesetdrugi").style.backgroundColor="white";
    document.getElementById("dvadesetdrugi").style.color="red";
}

function dvadesetdrugi2(){
    document.getElementById("dvadesetdrugi").style.transition=".5s"
    document.getElementById("dvadesetdrugi").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadesetdrugi").style.color="white";
}

function dvadesettreci(){
    document.getElementById("dvadesettreci").style.transition=".5s"
    document.getElementById("dvadesettreci").style.backgroundColor="white";
    document.getElementById("dvadesettreci").style.color="red"; 
}

function dvadesettreci2(){
    document.getElementById("dvadesettreci").style.transition=".5s"
    document.getElementById("dvadesettreci").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadesettreci").style.color="white"; 

}
 function dvadesetcetvrti(){
    document.getElementById("dvadesetcetvrti").style.transition=".5s"
    document.getElementById("dvadesetcetvrti").style.backgroundColor="white";
    document.getElementById("dvadesetcetvrti").style.color="red";
 }

 function dvadesetcetvrti2(){
    document.getElementById("dvadesetcetvrti").style.transition=".5s"
    document.getElementById("dvadesetcetvrti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadesetcetvrti").style.color="white";
}

function deveta(){
    document.getElementById("deveta").style.transition=".5s"
    document.getElementById("deveta").style.filter="brightness(30%)";
    document.getElementById("botuni_deveti").style.visibility="visible";
}

function deveta2(){
    document.getElementById("deveta").style.filter="brightness(60%)";
    document.getElementById("botuni_deveti").style.visibility="hidden";
}

function predi9(){
    document.getElementById("deveta").style.filter="brightness(30%)";
    document.getElementById("botuni_deveti").style.visibility="visible";
}

function makni9(){
    document.getElementById("deveta").style.filter="brightness(30%)";
    document.getElementById("botuni_deveti").style.visibility="visible";
}

function dvadesetpeti(){
    document.getElementById("dvadesetpeti").style.transition=".5s"
    document.getElementById("dvadesetpeti").style.backgroundColor="white";
    document.getElementById("dvadesetpeti").style.color="red";
}

function dvadesetpeti2(){
    document.getElementById("dvadesetpeti").style.transition=".5s"
    document.getElementById("dvadesetpeti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadesetpeti").style.color="white";
}

function dvadesetsesti(){
    document.getElementById("dvadesetsesti").style.transition=".5s"
    document.getElementById("dvadesetsesti").style.backgroundColor="white";
    document.getElementById("dvadesetsesti").style.color="red"; 
}

function dvadesetsesti2(){
    document.getElementById("dvadesetsesti").style.transition=".5s"
    document.getElementById("dvadesetsesti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadesetsesti").style.color="white"; 

}
 function svadesetsedmi(){
    document.getElementById("svadesetsedmi").style.transition=".5s"
    document.getElementById("svadesetsedmi").style.backgroundColor="white";
    document.getElementById("svadesetsedmi").style.color="red";
 }

 function svadesetsedmi2(){
    document.getElementById("svadesetsedmi").style.transition=".5s"
    document.getElementById("svadesetsedmi").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("svadesetsedmi").style.color="white";
}

function deseta(){
    document.getElementById("deseta").style.transition=".5s"
    document.getElementById("deseta").style.filter="brightness(30%)";
    document.getElementById("botuni_deseti").style.visibility="visible";
}

function deseta2(){
    document.getElementById("deseta").style.filter="brightness(60%)";
    document.getElementById("botuni_deseti").style.visibility="hidden";
}

function predi10(){
    document.getElementById("deseta").style.filter="brightness(30%)";
    document.getElementById("botuni_deseti").style.visibility="visible";
}

function makni10(){
    document.getElementById("deseta").style.filter="brightness(30%)";
    document.getElementById("botuni_deseti").style.visibility="visible";
}

function dvadesetosmi(){
    document.getElementById("dvadesetosmi").style.transition=".5s"
    document.getElementById("dvadesetosmi").style.backgroundColor="white";
    document.getElementById("dvadesetosmi").style.color="red";
}

function dvadesetosmi2(){
    document.getElementById("dvadesetosmi").style.transition=".5s"
    document.getElementById("dvadesetosmi").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadesetosmi").style.color="white";
}

function dvadesetdeveti(){
    document.getElementById("dvadesetdeveti").style.transition=".5s"
    document.getElementById("dvadesetdeveti").style.backgroundColor="white";
    document.getElementById("dvadesetdeveti").style.color="red"; 
}

function dvadesetdeveti2(){
    document.getElementById("dvadesetdeveti").style.transition=".5s"
    document.getElementById("dvadesetdeveti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("dvadesetdeveti").style.color="white"; 

}
 function trideseti(){
    document.getElementById("trideseti").style.transition=".5s"
    document.getElementById("trideseti").style.backgroundColor="white";
    document.getElementById("trideseti").style.color="red";
 }

 function trideseti2(){
    document.getElementById("trideseti").style.transition=".5s"
    document.getElementById("trideseti").style.backgroundColor="rgba(255, 255, 255, 0.35)";
    document.getElementById("trideseti").style.color="white";
}